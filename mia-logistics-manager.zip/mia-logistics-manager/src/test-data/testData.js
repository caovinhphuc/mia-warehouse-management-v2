// Test Data Initialization for MIA Logistics Manager
// This file contains sample data for testing and development

export const testUsers = [
  {
    id: 'admin_001',
    email: 'admin@mialogistics.com',
    password: 'admin123',
    name: 'Nguyễn Văn Admin',
    role: 'admin',
    department: 'Quản trị hệ thống',
    position: 'Quản trị viên',
    phone: '0901234567',
    avatar: null,
    isActive: true,
    lastLogin: '2024-01-15T10:30:00Z',
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 'manager_001',
    email: 'manager@mialogistics.com',
    password: 'manager123',
    name: 'Trần Thị Manager',
    role: 'manager',
    department: 'Vận hành',
    position: 'Quản lý vận hành',
    phone: '0901234568',
    avatar: null,
    isActive: true,
    lastLogin: '2024-01-15T09:15:00Z',
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 'operator_001',
    email: 'operator@mialogistics.com',
    password: 'operator123',
    name: 'Lê Văn Operator',
    role: 'operator',
    department: 'Điều hành',
    position: 'Nhân viên điều hành',
    phone: '0901234569',
    avatar: null,
    isActive: true,
    lastLogin: '2024-01-15T08:45:00Z',
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 'driver_001',
    email: 'driver@mialogistics.com',
    password: 'driver123',
    name: 'Phạm Văn Driver',
    role: 'driver',
    department: 'Vận chuyển',
    position: 'Tài xế',
    phone: '0901234570',
    avatar: null,
    isActive: true,
    lastLogin: '2024-01-15T07:30:00Z',
    createdAt: '2024-01-01T00:00:00Z',
    licenseNumber: 'B2-123456789',
    experienceYears: 5,
  },
  {
    id: 'warehouse_001',
    email: 'warehouse@mialogistics.com',
    password: 'warehouse123',
    name: 'Ngô Thị Warehouse',
    role: 'warehouse_staff',
    department: 'Kho bãi',
    position: 'Nhân viên kho',
    phone: '0901234571',
    avatar: null,
    isActive: true,
    lastLogin: '2024-01-15T07:00:00Z',
    createdAt: '2024-01-01T00:00:00Z',
  },
];

export const testTransportRequests = [
  {
    id: 'TR-2024-001',
    requestDate: '2024-01-15',
    customerId: 'CUST-001',
    customerName: 'Công ty TNHH ABC',
    customerPhone: '0281234567',
    customerEmail: 'abc@company.com',
    originAddress: '123 Nguyễn Văn Linh, Quận 7, TP.HCM',
    originLat: 10.732596,
    originLng: 106.719867,
    destinationAddress: '456 Lê Duẩn, Quận 1, TP.HCM',
    destinationLat: 10.787932,
    destinationLng: 106.705395,
    cargoType: 'Điện tử',
    cargoWeight: 500,
    cargoVolume: 2.5,
    cargoValue: 50000000,
    vehicleType: 'Xe tải 2.5 tấn',
    driverId: 'driver_001',
    driverName: 'Phạm Văn Driver',
    vehicleId: 'VH-001',
    vehiclePlate: '51F-12345',
    status: 'delivered',
    priority: 'normal',
    scheduledDate: '2024-01-15T08:00:00Z',
    actualStartDate: '2024-01-15T08:15:00Z',
    actualEndDate: '2024-01-15T10:30:00Z',
    distance: 15.2,
    estimatedCost: 500000,
    actualCost: 480000,
    fuelCost: 120000,
    tollCost: 0,
    otherCosts: 0,
    paymentMethod: 'bank_transfer',
    paymentStatus: 'paid',
    notes: 'Giao hàng thành công, khách hàng hài lòng',
    createdBy: 'operator_001',
    createdAt: '2024-01-14T16:00:00Z',
  },
  {
    id: 'TR-2024-002',
    requestDate: '2024-01-15',
    customerId: 'CUST-002',
    customerName: 'Công ty XYZ Ltd',
    customerPhone: '0281234568',
    customerEmail: 'xyz@company.com',
    originAddress: '789 Võ Văn Tần, Quận 3, TP.HCM',
    originLat: 10.782644,
    originLng: 106.691734,
    destinationAddress: '321 Điện Biên Phủ, Quận Bình Thạnh, TP.HCM',
    destinationLat: 10.806861,
    destinationLng: 106.716517,
    cargoType: 'Thực phẩm',
    cargoWeight: 1200,
    cargoVolume: 8.0,
    cargoValue: 25000000,
    vehicleType: 'Xe tải 5 tấn',
    driverId: 'driver_002',
    driverName: 'Lê Văn Tài',
    vehicleId: 'VH-002',
    vehiclePlate: '51F-67890',
    status: 'in_transit',
    priority: 'high',
    scheduledDate: '2024-01-15T14:00:00Z',
    actualStartDate: '2024-01-15T14:10:00Z',
    actualEndDate: null,
    distance: 8.7,
    estimatedCost: 350000,
    actualCost: null,
    fuelCost: 80000,
    tollCost: 0,
    otherCosts: 0,
    paymentMethod: 'cash',
    paymentStatus: 'pending',
    notes: 'Đang trên đường giao hàng',
    createdBy: 'operator_001',
    createdAt: '2024-01-15T10:00:00Z',
  },
  {
    id: 'TR-2024-003',
    requestDate: '2024-01-16',
    customerId: 'CUST-003',
    customerName: 'Siêu thị Big C',
    customerPhone: '0281234569',
    customerEmail: 'bigc@retail.com',
    originAddress: 'Kho MIA, Khu công nghiệp Tân Thuận, Quận 7, TP.HCM',
    originLat: 10.737622,
    originLng: 106.715507,
    destinationAddress: 'Big C Miền Đông, Quận Bình Thạnh, TP.HCM',
    destinationLat: 10.812831,
    destinationLng: 106.705611,
    cargoType: 'Hàng tiêu dùng',
    cargoWeight: 2500,
    cargoVolume: 15.0,
    cargoValue: 75000000,
    vehicleType: 'Xe tải 10 tấn',
    driverId: null,
    driverName: null,
    vehicleId: null,
    vehiclePlate: null,
    status: 'pending',
    priority: 'normal',
    scheduledDate: '2024-01-16T06:00:00Z',
    actualStartDate: null,
    actualEndDate: null,
    distance: null,
    estimatedCost: 800000,
    actualCost: null,
    fuelCost: null,
    tollCost: null,
    otherCosts: null,
    paymentMethod: 'credit',
    paymentStatus: 'pending',
    notes: 'Chờ phân công tài xế',
    createdBy: 'operator_001',
    createdAt: '2024-01-15T17:00:00Z',
  },
];

export const testWarehouseItems = [
  {
    id: 'WH-ITEM-001',
    itemCode: 'ELE-TV-001',
    itemName: 'Tivi Samsung 55 inch',
    category: 'Điện tử',
    supplier: 'Samsung Việt Nam',
    stockQuantity: 25,
    unit: 'chiếc',
    unitPrice: 15000000,
    location: 'Kho A - Kệ A1-01',
    warehouseLocation: 'Kho chính - Quận 7',
    expiryDate: null,
    description: 'Smart TV 4K, bảo hành 2 năm',
    status: 'available',
    minStockLevel: 5,
    maxStockLevel: 50,
    reorderPoint: 10,
    lastUpdated: '2024-01-15T08:00:00Z',
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 'WH-ITEM-002',
    itemCode: 'FOOD-RICE-001',
    itemName: 'Gạo ST25 - 5kg',
    category: 'Thực phẩm',
    supplier: 'HTX Nông nghiệp ABC',
    stockQuantity: 500,
    unit: 'bao',
    unitPrice: 150000,
    location: 'Kho B - Kệ B2-05',
    warehouseLocation: 'Kho thực phẩm - Quận 12',
    expiryDate: '2024-12-31',
    description: 'Gạo thơm cao cấp ST25',
    status: 'available',
    minStockLevel: 100,
    maxStockLevel: 1000,
    reorderPoint: 200,
    lastUpdated: '2024-01-15T07:30:00Z',
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 'WH-ITEM-003',
    itemCode: 'CLOTH-SHIRT-001',
    itemName: 'Áo sơ mi nam size M',
    category: 'Thời trang',
    supplier: 'May mặc Tân Bình',
    stockQuantity: 0,
    unit: 'chiếc',
    unitPrice: 250000,
    location: 'Kho C - Kệ C1-10',
    warehouseLocation: 'Kho thời trang - Quận 3',
    expiryDate: null,
    description: 'Áo sơ mi công sở nam màu trắng',
    status: 'out_of_stock',
    minStockLevel: 20,
    maxStockLevel: 200,
    reorderPoint: 50,
    lastUpdated: '2024-01-14T15:00:00Z',
    createdAt: '2024-01-01T00:00:00Z',
  },
];

export const testPartners = [
  {
    id: 'CUST-001',
    partnerCode: 'ABC-COMPANY',
    companyName: 'Công ty TNHH ABC',
    partnerType: 'customer',
    contactPerson: 'Nguyễn Văn A',
    phone: '0281234567',
    email: 'abc@company.com',
    address: '123 Nguyễn Văn Linh, Quận 7, TP.HCM',
    taxCode: '0123456789',
    contractType: 'annual',
    paymentTerms: 'credit_30',
    creditLimit: 100000000,
    currentDebt: 25000000,
    status: 'active',
    rating: 4.5,
    notes: 'Khách hàng lâu năm, thanh toán đúng hạn',
    createdAt: '2023-06-01T00:00:00Z',
    lastTransaction: '2024-01-15T10:30:00Z',
  },
  {
    id: 'SUPP-001',
    partnerCode: 'SAMSUNG-VN',
    companyName: 'Samsung Việt Nam',
    partnerType: 'supplier',
    contactPerson: 'Park Min Jun',
    phone: '0281234580',
    email: 'vietnam@samsung.com',
    address: '2 Hải Triều, Quận 1, TP.HCM',
    taxCode: '0987654321',
    contractType: 'project',
    paymentTerms: 'prepaid',
    creditLimit: 0,
    currentDebt: 0,
    status: 'active',
    rating: 5.0,
    notes: 'Nhà cung cấp uy tín, chất lượng cao',
    createdAt: '2023-01-15T00:00:00Z',
    lastTransaction: '2024-01-14T16:00:00Z',
  },
  {
    id: 'CARR-001',
    partnerCode: 'VIETTEL-POST',
    companyName: 'Viettel Post',
    partnerType: 'carrier',
    contactPerson: 'Trần Văn B',
    phone: '1900545454',
    email: 'partnership@viettelpost.vn',
    address: '15 Duy Tân, Cầu Giấy, Hà Nội',
    taxCode: '1234567890',
    contractType: 'annual',
    paymentTerms: 'credit_15',
    creditLimit: 50000000,
    currentDebt: 0,
    status: 'active',
    rating: 4.2,
    notes: 'Đối tác vận chuyển backup',
    createdAt: '2023-03-01T00:00:00Z',
    lastTransaction: '2024-01-10T14:20:00Z',
  },
];

export const testVehicles = [
  {
    id: 'VH-001',
    vehiclePlate: '51F-12345',
    vehicleType: 'Xe tải 2.5 tấn',
    brand: 'Hyundai',
    model: 'Porter H150',
    year: 2022,
    capacity: 2500,
    fuelType: 'diesel',
    fuelConsumption: 8.5,
    status: 'active',
    currentDriverId: 'driver_001',
    registrationExpiry: '2025-06-15',
    insuranceExpiry: '2024-12-31',
    lastMaintenance: '2024-01-01',
    nextMaintenance: '2024-04-01',
    notes: 'Xe mới, tình trạng tốt',
    createdAt: '2022-06-15T00:00:00Z',
  },
  {
    id: 'VH-002',
    vehiclePlate: '51F-67890',
    vehicleType: 'Xe tải 5 tấn',
    brand: 'Isuzu',
    model: 'NPR85K',
    year: 2021,
    capacity: 5000,
    fuelType: 'diesel',
    fuelConsumption: 12.0,
    status: 'active',
    currentDriverId: 'driver_002',
    registrationExpiry: '2025-03-20',
    insuranceExpiry: '2024-11-15',
    lastMaintenance: '2023-12-15',
    nextMaintenance: '2024-03-15',
    notes: 'Cần bảo dưỡng sớm',
    createdAt: '2021-03-20T00:00:00Z',
  },
];

export const testNotifications = [
  {
    id: 'NOTIF-001',
    type: 'transport',
    title: 'Đơn vận chuyển TR-2024-001 đã hoàn thành',
    message: 'Giao hàng thành công tại 456 Lê Duẩn, Quận 1, TP.HCM',
    priority: 'normal',
    isRead: false,
    userId: 'operator_001',
    data: {
      transportId: 'TR-2024-001',
      status: 'delivered'
    },
    createdAt: '2024-01-15T10:30:00Z',
  },
  {
    id: 'NOTIF-002',
    type: 'warehouse',
    title: 'Hàng hóa sắp hết tồn kho',
    message: 'Áo sơ mi nam size M (CLOTH-SHIRT-001) đã hết hàng',
    priority: 'high',
    isRead: false,
    userId: 'warehouse_001',
    data: {
      itemCode: 'CLOTH-SHIRT-001',
      currentStock: 0,
      minStock: 20
    },
    createdAt: '2024-01-14T15:00:00Z',
  },
  {
    id: 'NOTIF-003',
    type: 'system',
    title: 'Bảo trì hệ thống',
    message: 'Hệ thống sẽ bảo trì từ 2:00 - 4:00 sáng ngày 16/01/2024',
    priority: 'normal',
    isRead: true,
    userId: null, // broadcast to all users
    data: {
      maintenanceStart: '2024-01-16T02:00:00Z',
      maintenanceEnd: '2024-01-16T04:00:00Z'
    },
    createdAt: '2024-01-14T09:00:00Z',
  },
];

// Function to initialize test data in localStorage
export const initializeTestData = () => {
  try {
    // Store test data in localStorage for development
    localStorage.setItem('mia-test-users', JSON.stringify(testUsers));
    localStorage.setItem('mia-test-transports', JSON.stringify(testTransportRequests));
    localStorage.setItem('mia-test-warehouse', JSON.stringify(testWarehouseItems));
    localStorage.setItem('mia-test-partners', JSON.stringify(testPartners));
    localStorage.setItem('mia-test-vehicles', JSON.stringify(testVehicles));
    localStorage.setItem('mia-test-notifications', JSON.stringify(testNotifications));

    console.log('✅ Test data initialized successfully');
    return true;
  } catch (error) {
    console.error('❌ Failed to initialize test data:', error);
    return false;
  }
};

// Function to clear test data
export const clearTestData = () => {
  try {
    const keys = [
      'mia-test-users',
      'mia-test-transports', 
      'mia-test-warehouse',
      'mia-test-partners',
      'mia-test-vehicles',
      'mia-test-notifications'
    ];

    keys.forEach(key => localStorage.removeItem(key));
    console.log('✅ Test data cleared successfully');
    return true;
  } catch (error) {
    console.error('❌ Failed to clear test data:', error);
    return false;
  }
};

// Function to get test data
export const getTestData = (dataType) => {
  try {
    const data = localStorage.getItem(`mia-test-${dataType}`);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error(`❌ Failed to get test data for ${dataType}:`, error);
    return [];
  }
};

// Demo data for Google Sheets (CSV format for easy import)
export const generateSheetsCSV = {
  transportRequests: () => {
    const headers = [
      'ID', 'RequestDate', 'CustomerID', 'CustomerName', 'CustomerPhone',
      'CustomerEmail', 'OriginAddress', 'OriginLat', 'OriginLng', 'DestinationAddress',
      'DestinationLat', 'DestinationLng', 'CargoType', 'CargoWeight', 'CargoVolume',
      'CargoValue', 'VehicleType', 'DriverID', 'DriverName', 'VehicleID',
      'VehiclePlate', 'Status', 'Priority', 'ScheduledDate', 'ActualStartDate',
      'ActualEndDate', 'Distance', 'EstimatedCost', 'ActualCost', 'FuelCost',
      'TollCost', 'OtherCosts', 'PaymentMethod', 'PaymentStatus', 'Notes',
      'CreatedBy', 'CreatedAt', 'UpdatedBy', 'UpdatedAt', 'Route'
    ];

    const rows = testTransportRequests.map(item => [
      item.id, item.requestDate, item.customerId, item.customerName, item.customerPhone,
      item.customerEmail, item.originAddress, item.originLat, item.originLng, item.destinationAddress,
      item.destinationLat, item.destinationLng, item.cargoType, item.cargoWeight, item.cargoVolume,
      item.cargoValue, item.vehicleType, item.driverId, item.driverName, item.vehicleId,
      item.vehiclePlate, item.status, item.priority, item.scheduledDate, item.actualStartDate,
      item.actualEndDate, item.distance, item.estimatedCost, item.actualCost, item.fuelCost,
      item.tollCost, item.otherCosts, item.paymentMethod, item.paymentStatus, item.notes,
      item.createdBy, item.createdAt, '', '', ''
    ]);

    return [headers, ...rows].map(row => row.join(',')).join('\n');
  },

  warehouseInventory: () => {
    const headers = [
      'ID', 'ItemCode', 'ItemName', 'Category', 'Supplier',
      'StockQuantity', 'Unit', 'UnitPrice', 'Location', 'WarehouseLocation',
      'ExpiryDate', 'Description', 'Status', 'MinStockLevel', 'MaxStockLevel',
      'ReorderPoint', 'LastUpdated', 'CreatedAt'
    ];

    const rows = testWarehouseItems.map(item => [
      item.id, item.itemCode, item.itemName, item.category, item.supplier,
      item.stockQuantity, item.unit, item.unitPrice, item.location, item.warehouseLocation,
      item.expiryDate || '', item.description, item.status, item.minStockLevel, item.maxStockLevel,
      item.reorderPoint, item.lastUpdated, item.createdAt
    ]);

    return [headers, ...rows].map(row => row.join(',')).join('\n');
  }
};
